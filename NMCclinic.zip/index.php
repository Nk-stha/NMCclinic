<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NMC Clinic Butwal | Specialist Care, Diagnostics &amp; Physiotherapy</title>
<meta name="description" content="Specialist consultations, in-house diagnostics, laboratory services, physiotherapy, women's healthcare and kidney care at NMC Clinic, Traffic Chowk, Butwal.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page">

  <!-- ============ HEADER ============ -->
  <header class="site-header">
    <div class="topbar">
      <div class="topbar-in">
        <span class="topbar-item">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#FDCA00" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
          <span class="topbar-label">Emergency:</span> <a class="topbar-em" href="tel:+97771000000">+977 71-000000</a>
        </span>
        <span class="topbar-item">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#7FD4CA" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="m22 7-10 6L2 7"></path></svg>
          <a class="topbar-mail" href="mailto:info@nmcbutwal.com.np">info@nmcbutwal.com.np</a>
        </span>
        <span class="topbar-item">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#7FD4CA" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15 14"></polyline></svg>
          <span class="topbar-hours">Sun–Fri 8 AM–8 PM · Sat 9 AM–2 PM</span>
        </span>
        <div class="topbar-social">
          <a class="social-btn" href="#" aria-label="Facebook"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg></a>
          <a class="social-btn" href="#" aria-label="Instagram"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"></rect><circle cx="12" cy="12" r="4"></circle><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg></a>
          <a class="social-btn" href="https://wa.me/9779800000000" aria-label="WhatsApp"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38c1.45.79 3.08 1.21 4.79 1.21h.01c5.46 0 9.91-4.45 9.91-9.91C21.96 6.45 17.5 2 12.04 2z"></path></svg></a>
        </div>
      </div>
    </div>

    <div class="header-bar">
      <a class="brand" href="home" aria-current="page">
        <img src="uploads/logo.jpeg" alt="NMC clinic logo" width="48" height="48">
        <span class="brand-text">
          <span class="brand-name">NMC</span>
          <span class="brand-sub">Clinic ·&nbsp;</span>
        </span>
      </a>

      <nav class="nav-main" aria-label="Primary">
        <a href="home" aria-current="page">Home</a>
        <a href="about">About</a>
        <a href="specialties">Specialties</a>
        <a href="doctors">Doctors</a>
        <a href="blog">Blog</a>
        <a href="contact">Contact</a>
      </nav>

      <div class="header-actions">
        <a class="header-phone" href="tel:+97771000000">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
          +977 71-000000
        </a>
        <a class="btn btn-primary" href="home#appointment">Book Appointment</a>
      </div>

      <button class="nav-toggle" type="button" aria-label="Open menu" aria-expanded="false">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="4" y1="7" x2="20" y2="7"></line><line x1="4" y1="12" x2="20" y2="12"></line><line x1="4" y1="17" x2="20" y2="17"></line></svg>
      </button>
    </div>

    <div class="nav-mobile">
      <a href="home" aria-current="page">Home</a>
      <a href="about">About</a>
      <a href="specialties">Specialties</a>
      <a href="doctors">Doctors</a>
      <a href="blog">Blog</a>
      <a href="contact">Contact</a>
      <div class="nav-mobile-cta">
        <a class="m-book" href="home#appointment">Book Appointment</a>
        <a class="m-call" href="tel:+97771000000">Call +977 71-000000</a>
      </div>
    </div>
  </header>

  <!-- ============ HERO ============ -->
  <section class="hero" id="top">
    <div class="hero-veil"></div>
    <div class="hero-in">
      <div class="hero-copy">
        <span class="pill"><span class="dot"></span>Trusted Healthcare in Butwal</span>
        <h1>Care You Can Trust, Close to Home</h1>
        <p class="lead">Meet experienced doctors, complete essential tests, and receive follow-up care in one convenient clinic.</p>
        <div class="hero-actions">
          <a class="btn btn-primary btn-hero" href="#appointment">Book Appointment</a>
          <a class="btn btn-onhero" href="#services"><span class="hero-play"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span>Explore Our Services</a>
        </div>
        <p class="hero-note">Need help choosing a service? Call <a href="tel:+97771000000">+977 71-000000</a>.</p>
        <div class="hero-stats">
          <div><div class="hero-stat-t">Specialist Consultations</div><div class="hero-stat-s">Experienced doctors</div></div>
          <div><div class="hero-stat-t">In-house Diagnostics</div><div class="hero-stat-s">Lab &amp; imaging on site</div></div>
          <div><div class="hero-stat-t">Patient-focused Care</div><div class="hero-stat-s">Calm, coordinated support</div></div>
        </div>
      </div>
      <div class="hero-figure">
        <img src="uploads/doctor-herosec-cutout.png" width="1122" height="1402" fetchpriority="high"
             alt="Two friendly Nepali healthcare professionals — a female doctor in a white coat and a male colleague">
      </div>
    </div>
  </section>

  <!-- ============ QUICK ACTIONS ============ -->
  <section class="wrap quick-actions-wrap" aria-label="Quick actions">
    <div class="quick-actions">
      <a class="qa-card" href="#services">
        <span class="icon-badge"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 2 7l10 5 10-5-10-5z"></path><path d="m2 17 10 5 10-5"></path><path d="m2 12 10 5 10-5"></path></svg></span>
        <span class="qa-title">Our Services</span>
        <span class="qa-text">Explore our full range of specialties.</span>
        <span class="qa-more">Browse services <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span>
      </a>
      <a class="qa-card is-primary" href="tel:+97771000000">
        <span class="icon-badge on-teal"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"></path></svg></span>
        <span class="qa-title">Emergency</span>
        <span class="qa-text">Urgent guidance and how to reach us fast.</span>
        <span class="qa-more">Call +977 71-000000</span>
      </a>
      <a class="qa-card" href="#doctors">
        <span class="icon-badge"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg></span>
        <span class="qa-title">Find a Doctor</span>
        <span class="qa-text">Search specialists by department.</span>
        <span class="qa-more">See our team <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span>
      </a>
    </div>
  </section>

  <!-- ============ SERVICES ============ -->
  <section class="wrap home-pad-svc" id="services">
    <div class="head-split">
      <div>
        <span class="eyebrow">Our Services</span>
        <h2 class="section-title">Care for the Health Needs<br>That Matter Most</h2>
      </div>
      <div class="head-split-side">
        <p class="section-lead">From your first consultation to diagnosis and recovery, our services are designed to make healthcare easier to access.</p>
        <a class="link-cta inline" href="#appointment">Book a consultation <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
      </div>
    </div>
    <div class="grid grid-300 gap-20" data-cms-home-specialty-list>
        <article class="card card-hover svc-card">
          <span class="icon-badge"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2v6a6 6 0 0 0 12 0V2"></path><path d="M8 15v1a6 6 0 0 0 6 6 6 6 0 0 0 6-6v-4"></path><circle cx="20" cy="10" r="2"></circle></svg></span>
          <h3>Specialist Consultation</h3>
          <p>Personalized medical advice from experienced doctors.</p>
          <a class="link-cta inline" href="specialties#consultation">Learn More <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
        </article>
        <article class="card card-hover svc-card">
          <span class="icon-badge"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2v6l4.5 8a2 2 0 0 1-1.7 3H6.7A2 2 0 0 1 5 16l4.5-8V2"></path><path d="M8.5 2h7"></path><path d="M7 16h10"></path></svg></span>
          <h3>Advanced Diagnostics</h3>
          <p>In-house laboratory and imaging services for timely and accurate results.</p>
          <a class="link-cta inline" href="specialties#diagnostics">Learn More <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
        </article>
        <article class="card card-hover svc-card">
          <span class="icon-badge"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9 2v6.5L4.6 17A2 2 0 0 0 6.4 20h11.2a2 2 0 0 0 1.8-3L15 8.5V2"></path><line x1="8" y1="2" x2="16" y2="2"></line><circle cx="12" cy="15" r="1.3"></circle></svg></span>
          <h3>Laboratory Services</h3>
          <p>Reliable diagnostic testing, screening, and health monitoring.</p>
          <a class="link-cta inline" href="specialties#laboratory">Learn More <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
        </article>
        <article class="card card-hover svc-card">
          <span class="icon-badge"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="5" r="2"></circle><path d="M12 7v6"></path><path d="m9 21 3-4 3 4"></path><path d="M7 11h10"></path></svg></span>
          <h3>Physiotherapy &amp; Rehabilitation</h3>
          <p>Modern physiotherapy services for pain relief, recovery, and improved movement.</p>
          <a class="link-cta inline" href="specialties#physiotherapy">Learn More <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
        </article>
        <article class="card card-hover svc-card">
          <span class="icon-badge"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21.35 10.55 20C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54z"></path></svg></span>
          <h3>Obstetrics &amp; Gynecology</h3>
          <p>Comprehensive pregnancy, reproductive, and women's healthcare.</p>
          <a class="link-cta inline" href="specialties#women">Learn More <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
        </article>
        <article class="card card-hover svc-card">
          <span class="icon-badge"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3C8 3 5 6 5 10c0 3.5 2.5 6 4.5 7.5C11 18.7 11 21 12 21s1-2.3 2.5-3.5C16.5 16 19 13.5 19 10c0-4-3-7-7-7z"></path><path d="M12 9v4"></path></svg></span>
          <h3>Nephrology &amp; Kidney Care</h3>
          <p>Specialist diagnosis and treatment for kidney-related conditions.</p>
          <a class="link-cta inline" href="specialties#kidney">Learn More <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
        </article>
    </div>
  </section>

  <!-- ============ ABOUT ============ -->
  <section id="about">
    <div class="wrap split pad-about">
      <div class="split-media">
        <div class="about-photo">
          <img src="uploads/team-BJF-74gA.jpg" loading="lazy" width="640" height="480"
               alt="The NMC clinic team — doctors, nurses, and staff at the Butwal clinic">
        </div>
        <div class="stat-badge">
          <div class="stat-badge-num">6</div>
          <div class="stat-badge-txt">specialties under<br>one roof</div>
        </div>
      </div>
      <div class="split-body">
        <span class="eyebrow">About NMC</span>
        <h2 class="section-title">Healthcare That Feels Personal</h2>
        <p class="section-lead">NMC brings specialist consultations, diagnostic testing, physiotherapy, women's healthcare, and kidney care together in one convenient location. Our team focuses on listening carefully, explaining clearly, and helping every patient understand the next step in their care.</p>
        <ul class="tick-list">
          <li><span class="tick"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>Experienced medical professionals</li>
          <li><span class="tick"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>Modern diagnostic facilities</li>
          <li><span class="tick"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>Clear and respectful communication</li>
          <li><span class="tick"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>Coordinated care under one roof</li>
        </ul>
        <a class="btn btn-primary" href="about">Learn More About NMC</a>
      </div>
    </div>
  </section>

  <!-- ============ DIAGNOSTICS ============ -->
  <section class="band-light" id="diagnostics">
    <div class="wrap split pad-diag">
      <div class="split-body">
        <span class="eyebrow">Diagnostics</span>
        <h2 class="section-title">Faster Answers. Clearer Next Steps.</h2>
        <p class="section-lead">Our in-house laboratory and diagnostic services help you complete important tests without visiting multiple locations. Timely reports allow your doctor to review the results and guide your next step.</p>
        <a class="btn btn-primary" href="specialties#diagnostics">Explore Diagnostic Services</a>
      </div>
      <div class="split-media diag-list">
        <div class="diag-item">
          <span class="icon-badge"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9 11 3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg></span>
          <div>
            <div class="diag-title">In-house Laboratory</div>
            <div class="diag-text">Complete routine and specialist tests at the clinic.</div>
          </div>
        </div>
        <div class="diag-item">
          <span class="icon-badge"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9 11 3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg></span>
          <div>
            <div class="diag-title">Diagnostic Imaging</div>
            <div class="diag-text">Access available imaging services in one convenient location.</div>
          </div>
        </div>
        <div class="diag-item">
          <span class="icon-badge"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9 11 3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg></span>
          <div>
            <div class="diag-title">Timely Reports</div>
            <div class="diag-text">Receive clear information about when your report will be ready.</div>
          </div>
        </div>
        <div class="diag-item">
          <span class="icon-badge"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9 11 3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg></span>
          <div>
            <div class="diag-title">Coordinated Review</div>
            <div class="diag-text">Discuss your results with the appropriate doctor.</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ============ DOCTORS ============ -->
  <section class="wrap home-pad-88" id="doctors">
    <div class="center head-block">
      <span class="eyebrow">Our Medical Team</span>
      <h2 class="section-title">Meet the Doctors Behind Your Care</h2>
      <p class="section-lead">View specialties, consultation schedules, and choose the doctor who best matches your needs.</p>
    </div>
    <div class="tabs center-tabs" data-filter-group="home-doctors" data-cms-home-doctor-tabs aria-label="Filter doctors by specialty">
        <button type="button" class="tab is-active" data-filter="All" aria-pressed="true">All</button>
        <button type="button" class="tab" data-filter="General Medicine" aria-pressed="false">General Medicine</button>
        <button type="button" class="tab" data-filter="Obstetrics &amp; Gynecology" aria-pressed="false">Obstetrics &amp; Gynecology</button>
        <button type="button" class="tab" data-filter="Nephrology" aria-pressed="false">Nephrology</button>
        <button type="button" class="tab" data-filter="Physiotherapy" aria-pressed="false">Physiotherapy</button>
    </div>
    <div class="grid grid-260 gap-22" data-filter-target="home-doctors" data-cms-home-doctor-list>
        <article class="doc-card is-home" data-category="General Medicine">
          <div class="doc-photo"><span class="ph-label">doctor photo</span></div>
          <div class="doc-body">
            <span class="doc-chip">General Medicine</span>
            <h3>Dr. [Name]</h3>
            <p class="doc-qual">Qualification to be confirmed</p>
            <p class="doc-reg">NMC Reg. No. to be confirmed</p>
            <div class="doc-hours"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg> Sun &ndash; Fri</div>
            <div class="doc-actions">
              <a class="doc-view" href="doctors">View Profile</a>
              <a class="doc-book" href="#appointment">Book Appointment</a>
            </div>
          </div>
        </article>
        <article class="doc-card is-home" data-category="Obstetrics &amp; Gynecology">
          <div class="doc-photo"><span class="ph-label">doctor photo</span></div>
          <div class="doc-body">
            <span class="doc-chip">Obstetrics &amp; Gynecology</span>
            <h3>Dr. [Name]</h3>
            <p class="doc-qual">Qualification to be confirmed</p>
            <p class="doc-reg">NMC Reg. No. to be confirmed</p>
            <div class="doc-hours"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg> Mon &ndash; Sat</div>
            <div class="doc-actions">
              <a class="doc-view" href="doctors">View Profile</a>
              <a class="doc-book" href="#appointment">Book Appointment</a>
            </div>
          </div>
        </article>
        <article class="doc-card is-home" data-category="Nephrology">
          <div class="doc-photo"><span class="ph-label">doctor photo</span></div>
          <div class="doc-body">
            <span class="doc-chip">Nephrology</span>
            <h3>Dr. [Name]</h3>
            <p class="doc-qual">Qualification to be confirmed</p>
            <p class="doc-reg">NMC Reg. No. to be confirmed</p>
            <div class="doc-hours"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg> Sun, Tue, Thu</div>
            <div class="doc-actions">
              <a class="doc-view" href="doctors">View Profile</a>
              <a class="doc-book" href="#appointment">Book Appointment</a>
            </div>
          </div>
        </article>
        <article class="doc-card is-home" data-category="Physiotherapy">
          <div class="doc-photo"><span class="ph-label">doctor photo</span></div>
          <div class="doc-body">
            <span class="doc-chip">Physiotherapy</span>
            <h3>Dr. [Name]</h3>
            <p class="doc-qual">Qualification to be confirmed</p>
            <p class="doc-reg">NMC Reg. No. to be confirmed</p>
            <div class="doc-hours"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg> Sun &ndash; Fri</div>
            <div class="doc-actions">
              <a class="doc-view" href="doctors">View Profile</a>
              <a class="doc-book" href="#appointment">Book Appointment</a>
            </div>
          </div>
        </article>
    </div>
    <p class="listing-note" data-filter-empty="home-doctors" hidden>No doctors match this specialty yet.</p>
    <p class="listing-note" data-cms-home-doctor-fallback-note>Specialist names and profiles will be added as details are confirmed.</p>
  </section>

  <!-- ============ WHY CHOOSE US ============ -->
  <section class="band-dark">
    <div class="wrap home-pad-80">
      <div class="center head-block">
        <span class="eyebrow on-dark">Why Choose NMC</span>
        <h2 class="section-title on-dark">Care Designed Around Your Needs</h2>
      </div>
      <div class="grid grid-240 gap-20">
        <div class="dark-card">
          <span class="dark-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
          <h3>Experienced Specialists</h3>
          <p>Consult qualified medical professionals across key specialties.</p>
        </div>
        <div class="dark-card">
          <span class="dark-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
          <h3>Diagnostics Under One Roof</h3>
          <p>Complete consultations and available tests in one convenient location.</p>
        </div>
        <div class="dark-card">
          <span class="dark-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
          <h3>Clear Guidance at Every Step</h3>
          <p>Understand your condition, results, and treatment options more easily.</p>
        </div>
        <div class="dark-card">
          <span class="dark-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
          <h3>Respectful and Coordinated Care</h3>
          <p>Receive support from a team that listens and works together.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ============ APPOINTMENT ============ -->
  <section class="band-light" id="appointment">
    <div class="wrap home-pad-80 appointment">
      <div class="appointment-copy">
        <span class="eyebrow">Appointments</span>
        <h2 class="section-title">Book Your Visit</h2>
        <p class="section-lead">Choose a service and your preferred date. Our reception team will contact you to confirm the appointment time.</p>
        <div class="dept-help">
          <span class="icon-badge"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"></path></svg></span>
          <div>
            <div class="dept-help-title">Not sure which department?</div>
            <div class="dept-help-text">Call reception at <a href="tel:+97771000000">+977 71-000000</a></div>
          </div>
        </div>
      </div>

      <div class="appointment-form-col">
        <form class="form-card is-home" data-success="appointment-ok" action="submit-appointment.php" method="post">
          <div class="grid grid-200 form-grid">
            <div class="field">
              <label for="f-name">Full name</label>
              <input class="input" id="f-name" name="name" type="text" required placeholder="Your name">
            </div>
            <div class="field">
              <label for="f-phone">Phone number</label>
              <input class="input" id="f-phone" name="phone" type="tel" required placeholder="+977 …">
            </div>
            <div class="field">
              <label for="f-service">Service or department</label>
              <select class="select" id="f-service" name="service">
                <option value="">Select a service</option>
                <option>Specialist Consultation</option>
                <option>Advanced Diagnostics</option>
                <option>Laboratory Services</option>
                <option>Physiotherapy &amp; Rehabilitation</option>
                <option>Obstetrics &amp; Gynecology</option>
                <option>Nephrology &amp; Kidney Care</option>
              </select>
            </div>
            <div class="field">
              <label for="f-date">Preferred date</label>
              <input class="input" id="f-date" name="date" type="date">
            </div>
            <div class="field">
              <label for="f-time">Preferred time</label>
              <select class="select" id="f-time" name="time">
                <option value="">Any time</option>
                <option>Morning (8 AM &ndash; 12 PM)</option>
                <option>Afternoon (12 &ndash; 4 PM)</option>
                <option>Evening (4 &ndash; 8 PM)</option>
              </select>
            </div>
          </div>
          <div class="field">
            <label for="f-msg">Message <span class="optional">(optional)</span></label>
            <textarea class="textarea" id="f-msg" name="message" rows="3" placeholder="Anything you'd like us to know"></textarea>
          </div>
          <label class="consent">
            <input type="checkbox" name="consent_accepted" value="1" required>
            <span>I agree to be contacted by NMC about this appointment request.</span>
          </label>
          <button class="btn btn-primary btn-block" type="submit">Request an Appointment</button>
          <div class="form-ok" id="appointment-ok" role="status" hidden>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            Thank you — your request has been noted for this preview.
          </div>
          <p class="form-note">This request does not confirm your appointment. Our reception team will call you to confirm the date and time.</p>
        </form>
      </div>
    </div>
  </section>

  <!-- ============ PATIENT INFORMATION ============ -->
  <section class="wrap home-pad-88">
    <div class="center head-block">
      <span class="eyebrow">Before Your Visit</span>
      <h2 class="section-title">Helpful Information for Patients</h2>
      <p class="section-lead">A few simple details can help you prepare for a smoother clinic visit.</p>
    </div>
    <div class="grid grid-260 gap-20">
        <div class="card">
          <span class="icon-badge lg"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg></span>
          <h3>What to Bring</h3>
          <p>Bring a valid ID, previous reports, prescriptions, and a list of current medicines.</p>
        </div>
        <div class="card">
          <span class="icon-badge lg"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg></span>
          <h3>Opening Hours</h3>
          <p>Check the clinic schedule before travelling, especially during public holidays.</p>
        </div>
        <div class="card">
          <span class="icon-badge lg"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg></span>
          <h3>Test Preparation</h3>
          <p>Some tests may require fasting or other preparation. Contact the clinic when unsure.</p>
        </div>
        <div class="card">
          <span class="icon-badge lg"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg></span>
          <h3>Reports and Payment</h3>
          <p>Ask reception when your report will be ready and which payment methods are accepted.</p>
        </div>
    </div>
    <div class="section-foot">
      <a class="btn btn-primary" href="contact">View the Complete Patient Guide <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
    </div>
    <div class="notice notice-warn patient-warn">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#124E4A" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
      <p>For a medical emergency, visit the nearest emergency department or contact the appropriate emergency service immediately.</p>
    </div>
  </section>

  <!-- ============ TESTIMONIAL ============ -->
  <section class="band-cream-home">
    <div class="wrap home-pad-80">
      <div class="center head-block">
        <span class="eyebrow">Patient stories</span>
        <h2 class="section-title testi-title">What Our Patients Say</h2>
        <p class="section-lead">Real experiences shared by patients who received care at NMC.</p>
      </div>
      <div class="testimonial-box">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        <p>Verified patient experiences will be published here with permission.</p>
      </div>
    </div>
  </section>

  <!-- ============ HEALTH ARTICLES ============ -->
  <section class="wrap home-pad-top24" id="articles">
    <div class="head-split">
      <div>
        <span class="eyebrow">Health Guides</span>
        <h2 class="section-title">Clear Information for Better Health Decisions</h2>
      </div>
      <div class="head-split-side">
        <p class="section-lead">Practical articles reviewed by healthcare professionals to help you understand common conditions, tests, and treatments.</p>
      </div>
    </div>
    <div class="grid grid-280 gap-22" data-cms-home-blog-list>
        <a class="post-card" href="blog/kidney-health-early-signs-you-should-not-ignore">
          <div class="post-photo">
            <span class="ph-label">article image</span>
            <span class="doc-tag">Kidney Care</span>
          </div>
          <div class="post-body">
            <div class="post-meta">5 min read</div>
            <h3>Kidney Health: Early Signs You Should Not Ignore</h3>
            <p>Small changes can be easy to miss. Here's what's worth checking with a doctor.</p>
            <div class="post-byline">Reviewed by NMC medical team &middot; Reviewed [Month Year]</div>
            <span class="link-cta inline">Read article <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span>
          </div>
        </a>
        <a class="post-card" href="blog/preparing-for-a-diagnostic-test">
          <div class="post-photo">
            <span class="ph-label">article image</span>
            <span class="doc-tag">Diagnostics</span>
          </div>
          <div class="post-body">
            <div class="post-meta">6 min read</div>
            <h3>Preparing for a Diagnostic Test</h3>
            <p>Simple steps like fasting or timing that help your test run smoothly.</p>
            <div class="post-byline">Reviewed by NMC medical team &middot; Reviewed [Month Year]</div>
            <span class="link-cta inline">Read article <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span>
          </div>
        </a>
        <a class="post-card" href="blog/everyday-habits-that-support-womens-health">
          <div class="post-photo">
            <span class="ph-label">article image</span>
            <span class="doc-tag">Women's Health</span>
          </div>
          <div class="post-body">
            <div class="post-meta">4 min read</div>
            <h3>Everyday Habits That Support Women's Health</h3>
            <p>Small, practical routines that support well-being at every stage of life.</p>
            <div class="post-byline">Reviewed by NMC medical team &middot; Reviewed [Month Year]</div>
            <span class="link-cta inline">Read article <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span>
          </div>
        </a>
    </div>
    <div class="section-foot">
      <a class="btn btn-primary" href="blog">View All Health Guides <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
      <span class="note" data-cms-home-blog-fallback-note>Sample topics shown — real articles from our team will be published here.</span>
    </div>
  </section>

  <!-- ============ LOCATION & CONTACT ============ -->
  <section class="wrap home-pad-88" id="contact">
    <div class="center head-block">
      <span class="eyebrow">Visit us</span>
      <h2 class="section-title">Location &amp; Contact</h2>
      <p class="section-lead">Two convenient locations in Butwal and Bhairahawa — reach our reception team any day we're open.</p>
    </div>
    <div class="contact-split">
      <div class="contact-form-col">
        <div class="branch-list">
          <div class="branch">
            <span class="icon-badge md"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></span>
            <div>
              <div class="branch-head"><span class="branch-name">Butwal Branch</span><span class="branch-tag">Main clinic</span></div>
              <div class="branch-text">Traffic Chowk, Butwal, Rupandehi, Nepal<br><a href="tel:+97771000000">+977 71-000000</a></div>
            </div>
          </div>
          <div class="branch">
            <span class="icon-badge md"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></span>
            <div>
              <div class="branch-head"><span class="branch-name">Bhairahawa Branch</span><span class="branch-tag is-soft">Branch</span></div>
              <div class="branch-text">Siddharthanagar, Rupandehi, Nepal<br><a href="tel:+9779800000000">+977 98-0000000</a></div>
            </div>
          </div>
          <div class="branch">
            <span class="icon-badge md"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#287772" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="m22 7-10 6L2 7"></path></svg></span>
            <div>
              <div class="branch-name">Email us</div>
              <div class="branch-text"><a href="mailto:info@nmcbutwal.com.np">info@nmcbutwal.com.np</a></div>
            </div>
          </div>
          <div class="branch">
            <span class="icon-badge md is-warm"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#124E4A" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15 14"></polyline></svg></span>
            <div>
              <div class="branch-name">Opening hours</div>
              <div class="branch-text">Sun&ndash;Fri: 8:00 AM &ndash; 8:00 PM<br>Saturday: 9:00 AM &ndash; 2:00 PM</div>
            </div>
          </div>
        </div>
      </div>
      <div class="contact-side">
        <div class="map-frame">
          <iframe title="NMC clinic location in Butwal, Nepal" loading="lazy"
                  src="https://www.openstreetmap.org/export/embed.html?bbox=83.40%2C27.66%2C83.50%2C27.74&amp;layer=mapnik&amp;marker=27.700%2C83.448"></iframe>
        </div>
        <a class="btn btn-outline btn-block" href="https://www.openstreetmap.org/?mlat=27.700&amp;mlon=83.448#map=14/27.700/83.448" target="_blank" rel="noopener">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="3 11 22 2 13 21 11 13 3 11"></polygon></svg> Get Directions
        </a>
        <p class="form-note center">Map location is approximate — exact address and nearby landmarks will be confirmed.</p>
      </div>
    </div>
  </section>

  <!-- ============ FOOTER ============ -->
  <footer class="site-footer">
    <div class="footer-in">
      <div class="footer-grid">
        <div>
          <div class="footer-brand">
            <img src="uploads/logo.jpeg" alt="NMC clinic logo" width="44" height="44" loading="lazy">
            <span>NMC</span>
          </div>
          <p class="footer-about">A community clinic in Butwal offering specialist consultation, diagnostics, physiotherapy, women's health, and kidney care under one roof.</p>
          <a class="footer-phone" href="tel:+97771000000">+977 71-000000</a>
        </div>
        <div>
          <h4>Quick Links</h4>
          <div class="footer-list">
            <a href="#top">Home</a>
            <a href="#about">About</a>
            <a href="#doctors">Doctors</a>
            <a href="#appointment">Book Appointment</a>
            <a href="#contact">Contact</a>
          </div>
        </div>
        <div>
          <h4>Services</h4>
          <div class="footer-list">
            <a href="specialties#consultation">Specialist Consultation</a>
            <a href="specialties#diagnostics">Advanced Diagnostics</a>
            <a href="specialties#laboratory">Laboratory Services</a>
            <a href="specialties#physiotherapy">Physiotherapy</a>
            <a href="specialties#kidney">Kidney Care</a>
          </div>
        </div>
        <div>
          <h4>Contact</h4>
          <div class="footer-list footer-contact">
            <span>Traffic Chowk, Butwal, Rupandehi, Nepal</span>
            <a href="mailto:info@nmcbutwal.com.np">info@nmcbutwal.com.np</a>
            <span>Sun–Fri: 8 AM – 8 PM</span>
            <span>Saturday: 9 AM – 2 PM</span>
          </div>
        </div>
      </div>

      <div class="footer-emergency">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FDCA00" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
        <p>For medical emergencies, contact the nearest emergency service or hospital immediately.</p>
      </div>

      <div class="footer-bottom">
        <span>© <span data-year>2026</span> NMC Clinic, Butwal. All rights reserved.</span>
        <div class="footer-legal">
          <a href="#">Privacy Policy</a>
          <a href="#">Terms &amp; Conditions</a>
          <a href="#">Accessibility</a>
        </div>
      </div>
    </div>
  </footer>

  <!-- ============ WHATSAPP FLOAT ============ -->
  <a class="wa-float" href="https://wa.me/9779800000000" target="_blank" rel="noopener" aria-label="Chat with us on WhatsApp">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="#ffffff" aria-hidden="true"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38c1.45.79 3.08 1.21 4.79 1.21h.01c5.46 0 9.91-4.45 9.91-9.91C21.96 6.45 17.5 2 12.04 2zm5.8 14.04c-.24.68-1.42 1.32-1.95 1.37-.5.05-1.13.07-1.83-.11-.42-.11-.96-.29-1.66-.59-2.92-1.26-4.83-4.2-4.98-4.4-.15-.2-1.19-1.58-1.19-3.01 0-1.43.75-2.13 1.02-2.42.27-.29.58-.36.78-.36.19 0 .39 0 .56.01.18.01.42-.07.66.5.24.59.82 2.02.89 2.17.07.15.12.32.02.51-.09.2-.14.32-.28.49-.14.17-.29.38-.42.51-.14.14-.28.29-.12.57.16.28.72 1.19 1.55 1.93 1.06.95 1.96 1.24 2.24 1.38.28.14.44.12.6-.07.16-.19.69-.8.87-1.08.18-.28.36-.23.61-.14.25.09 1.61.76 1.89.9.28.14.46.21.53.32.07.12.07.66-.17 1.34z"></path></svg>
    WhatsApp us
  </a>

</div>
<script src="assets/script.js"></script>
</body>
</html>
